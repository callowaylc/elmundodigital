<?php echo get_option('of_nw_archive'); ?>
