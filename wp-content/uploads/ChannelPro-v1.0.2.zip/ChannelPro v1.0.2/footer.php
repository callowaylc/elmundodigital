</div><!--end #main-->
  
		<?php if ( is_active_sidebar( 'footer-widget-area-1' ) || is_active_sidebar( 'footer-widget-area-2' ) || is_active_sidebar( 'footer-widget-area-3' ) || is_active_sidebar( 'footer-widget-area-4' )) { ?>
		<div id="footer">
			<div class="widget" id="fwidget-1">
				<?php if ( is_active_sidebar( 'footer-widget-area-1' ) ) :  dynamic_sidebar( 'footer-widget-area-1'); endif; ?>
			</div>
	
			<div class="widget" id="fwidget-2">
				<?php if ( is_active_sidebar( 'footer-widget-area-2' ) ) :  dynamic_sidebar( 'footer-widget-area-2'); endif; ?>
			</div>
			
			<div class="widget" id="fwidget-3">
				<?php if ( is_active_sidebar( 'footer-widget-area-3' ) ) :  dynamic_sidebar( 'footer-widget-area-3'); endif; ?>
			</div>
		
			<div class="widget" id="fwidget-4">				
				<?php if ( is_active_sidebar( 'footer-widget-area-4' ) ) :  dynamic_sidebar( 'footer-widget-area-4'); endif; ?>
			</div>
		</div>
		<?php } ?>
	
		<div id="bottom">
			
			<div class="left">
			
				&copy; <?php echo mysql2date('Y',current_time('timestamp')); ?> <a href="<?php bloginfo('url'); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>. <?php _e('All rights reserved','themejunkie'); ?>. <a href="http://validator.w3.org/check?uri=referer" target="_blank"><?php _e('XHTML','themejunkie'); ?></a> / <a href="http://jigsaw.w3.org/css-validator/check?uri=referer" target="_blank"><?php _e('CSS','themejunkie'); ?></a> <?php _e('Valid','themejunkie'); ?>.
			</div> <!--end .left--> 
			
			<div class="right">
				<?php _e('Proudly designed by','themejunkie'); ?> <a href="http://www.theme-junkie.com"><?php _e('Theme Junkie','themejunkie'); ?></a>.
			</div> <!--end .right-->
				
			<div class="clear"></div>
		
		</div> <!--end #bottom -->
  
</div> <!--end #wrapper -->

<!--begin of body code-->	
<?php if(get_theme_mod('body_code_status') == "Yes") echo stripslashes(get_theme_mod('body_code')); ?>
<!--end of body code-->

<?php wp_footer(); ?>

</body>
</html>