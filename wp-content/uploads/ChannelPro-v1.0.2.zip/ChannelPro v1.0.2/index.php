<?php get_header(); ?>

<div id="container">

	<div id="content">
		<?php include(TEMPLATEPATH. '/includes/home-featured.php'); ?>
						
		<div class="content-loop">
			<?php 
				$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
				$wp_query = new WP_Query('posts_per_page='.get_theme_mod('home_postnum').'&paged=' . $paged);
				if (have_posts()) {
				$counter = 0;
					while (have_posts()) : the_post();
						global $post;
						include(TEMPLATEPATH. '/includes/home-loop.php');
						
						if( $counter % 2 != 0 )
						echo'<div class="clear"> </div>';
						$counter++;

					endwhile;
				} else { 
					include(TEMPLATEPATH. '/includes/not-found.php'); 
				}
				
				if ( $wp_query->max_num_pages > 1 ) tj_pagenavi();
				wp_reset_query();
			?>
			
		</div>
		
	</div><!--end #content-->
	
	<?php get_sidebar(); ?>
	
</div><!--end #container-->


<?php get_footer(); ?>