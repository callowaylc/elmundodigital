<div id="post-0" class="hentry post error404 not-found">
	<div class="entry entry-content">
		<p><?php _e( 'Apologies, but no results were found for the requested Archive. Perhaps searching will help find a related post.', 'themejunkie' ); ?></p>
	</div> <!--end .entry-->
</div> <!--end #post-->
