ChannelPro WordPress Theme v1.0
http://www.theme-junkie.com/themes/channelpro


INSTALL: 
1. Upload the theme folder via FTP to your wp-content/themes/ directory.
2. Go to your WordPress dashboard and select Appearance.
3. Select ChannelPro WordPress theme.
4. Inside your WordPress dashboard, go to Appearance > ChannelPro Theme Options & Appearance > Widgets and configure them to your liking.

FAQ:
* How to create thumbnails
With the built-in theme functions you have three options to create thumbnails:
1. Auto thumbnail creation:
If you would like to create thumbnails for homepage and archive pages, just simply upload an image and insert to the post,
the thumbnail will be automatically created, no custom fields needed.

2. Custom field for thumbnail creation:
If you would like to create thumbnails via custom field instead of auto-creation, just simply add a custom field to the post:
Custom field name: thumb
Custom field value: IMAGE LINK (i.e. http://www.yoursite.com/wp-content/uploads/2009/10/sample.jpg)

3. WordPress 2.9+ Featured Image

If you are looking for theme support, please visit our support forum: http://www.theme-junkie.com/support

Thanks,
Theme Junkie Team
www.theme-junkie.com