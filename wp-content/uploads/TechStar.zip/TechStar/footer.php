  <div class="span-24">
		<div id="footer">Copyright &copy; <a href="<?php bloginfo('home'); ?>"><strong><?php bloginfo('name'); ?></strong></a>  - <?php bloginfo('description'); ?></div>
        <?php // This theme is released free for use under creative commons licence. http://creativecommons.org/licenses/by/3.0/
            // All links in the footer should remain intact. 
            // These links are all family friendly and will not hurt your site in any way. 
            // Warning! Your site may stop working if these links are edited or deleted 
            
        // You can buy this theme without footer links online at http://newwpthemes.com/buy/ ?>
        <div id="credits">Powered by <a href="http://wordpress.org/"><strong>WordPress</strong></a> | Designed by: <a href="http://www.apps4rent.com/sharepoint.html">SharePoint Site</a> | Thanks to <a href="http://www.apps4rent.com/virtual-dedicated-private-server-windows-hyper-v-vds-vs-vps-hosting/virtual-dedicated-server.html">Virtual Server Hosting</a>, <a href="http://www.apps4rent.com/email-hosting.html">Business Email Hosting</a> and <a href="http://www.apps4rent.com/microsoft-project-server-hosting.html">Project Server 2010</a></div>
    </div>
</div>
</div>
<?php
	 wp_footer();
	echo get_theme_option("footer")  . "\n";
?>
</body>
</html>