<?php 
if(!function_exists('imagecreatetruecolor')) {
	echo 'GD Library Error: imagecreatetruecolor does not exist - please contact your webhost and ask them to install the GD library';
} 
?>