	 <div class="fsearchbg1"> 
      	<form method="get" id="footersearch1" action="<?php bloginfo('url'); ?>/">
<input type="text" name="s" value="Search News - Enter Keyword" onblur="if(this.value=='') this.value='Search News - Enter Keyword';" onfocus="if(this.value=='Search News - Enter Keyword') this.value='';" id="s" />
			<input type="submit" value=" " id="searchsubmit" />
		   </form>
       </div>